from __future__ import annotations

from typing import TYPE_CHECKING

from typing import Dict

if TYPE_CHECKING:
    from mytypes import Links, Matrix, ColumnVector, Links, Features, ParametersDict, Paths, Union, Option, Options, Vector, Optional










