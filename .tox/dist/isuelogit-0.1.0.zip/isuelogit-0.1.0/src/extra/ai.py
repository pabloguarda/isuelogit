""" Optimize and make the system smarter by using tecniques drawn from artifitial intelligence
It will try to challenge the conventional principles used by ITS

"""


class AI:
    def __init__(self):
        #self._network = network
        pass

    def metro_choiceset_generation(self, origin, destination, od_traveltimes, traveltime, network):

        mode = "random"

        alternatives = []

        if mode == "random":
            routes



