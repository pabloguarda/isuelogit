=====
Usage
=====

To use isuelogit in a project::

    import isuelogit
