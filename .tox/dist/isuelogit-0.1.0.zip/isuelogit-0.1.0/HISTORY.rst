=======
History
=======

0.1.0 (2020-02-21)
------------------

* First release on PyPI.
